#include <stdio.h>

struct student {
    char *name;
} stu; 


int main(int argc, const char *argv[])
{
    char *name = "george";

    stu.name = "student";

    printf("&stu=%x, stu.name=%x\n",&stu,stu.name);
    printf("&stu=%x, stu.name=%x\n",&stu,&stu.name);

    printf("&stu=%x, stu.name=%x\n",stu,&stu.name);
    
    return 0;
}
